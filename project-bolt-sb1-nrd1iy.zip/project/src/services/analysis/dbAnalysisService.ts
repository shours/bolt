import { supabase } from '../../lib/supabase';
import { Database } from '../../types/database';
import { AnalysisResponse } from '../../types/analysis';

type Analysis = Database['public']['Tables']['search_intent_analyses']['Row'];

export const dbAnalysisService = {
  async saveAnalysis(projectId: string, analysis: AnalysisResponse): Promise<Analysis> {
    const { data, error } = await supabase
      .from('search_intent_analyses')
      .upsert({
        project_id: projectId,
        content: analysis.content,
        serpamics_id: analysis.serpamicsId,
        status: 'completed'
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async getAnalysis(projectId: string): Promise<Analysis | null> {
    const { data, error } = await supabase
      .from('search_intent_analyses')
      .select('*')
      .eq('project_id', projectId)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    return data;
  }
};