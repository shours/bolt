import axios from 'axios';
import { SaveAnalysisData } from '../types/analysis';
import { validateSaveData } from '../utils/validators';
import { formatSavePayload } from '../utils/formatters';

const SAVE_WEBHOOK_URL = 'https://hook.eu2.make.com/o4fy8bpq5l6qognoutx4sfxrvgub2kel';

const api = axios.create({
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

export const saveAnalysis = async (data: SaveAnalysisData): Promise<void> => {
  validateSaveData(data);

  try {
    const payload = formatSavePayload(data);
    const response = await api.post(SAVE_WEBHOOK_URL, payload);
    
    if (!response.data || response.status !== 200) {
      throw new Error('Invalid response from save webhook');
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(`Network error during save: ${error.message}`);
    }
    throw error instanceof Error 
      ? error 
      : new Error('Failed to save analysis');
  }
};