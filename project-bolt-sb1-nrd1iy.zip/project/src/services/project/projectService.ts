import { supabase } from '../../lib/supabase';
import { Database } from '../../types/database';

type Project = Database['public']['Tables']['projects']['Row'];
type ProjectInsert = Database['public']['Tables']['projects']['Insert'];

export const projectService = {
  async createProject(data: ProjectInsert): Promise<Project> {
    const { data: project, error } = await supabase
      .from('projects')
      .insert(data)
      .select()
      .single();

    if (error) throw error;
    return project;
  },

  async updateProjectStatus(id: string, status: Project['status']): Promise<void> {
    const { error } = await supabase
      .from('projects')
      .update({ status })
      .eq('id', id);

    if (error) throw error;
  },

  async getProject(id: string): Promise<Project> {
    const { data: project, error } = await supabase
      .from('projects')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return project;
  },

  async deleteProject(id: string): Promise<void> {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
};