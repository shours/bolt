export interface AnalysisFormData {
  keyword: string;
  language: string;
  searchEngine: string;
  projectId?: string;
}

export interface AnalysisResponse {
  content: string;
  serpamicsId: string;
  keyword: string;
  language: string;
  error?: string;
}

export interface SaveAnalysisData {
  serpamicsId: string;
  keyword: string;
  content: string;
  language?: string;
  projectId?: string;
}

export interface AnalysisState {
  isLoading: boolean;
  error: string | null;
  result: string | null;
  isEditing: boolean;
  serpamicsId: string | null;
  keyword: string | null;
  language: string | null;
}