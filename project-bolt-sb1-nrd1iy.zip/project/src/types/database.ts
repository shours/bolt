export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      projects: {
        Row: {
          id: string
          user_id: string
          name: string
          status: 'draft' | 'analysis' | 'brief' | 'writing' | 'completed'
          created_at: string
          updated_at: string
          primary_keyword: string | null
          target_language: string | null
          search_engine: string | null
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          status?: 'draft' | 'analysis' | 'brief' | 'writing' | 'completed'
          created_at?: string
          updated_at?: string
          primary_keyword?: string | null
          target_language?: string | null
          search_engine?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          status?: 'draft' | 'analysis' | 'brief' | 'writing' | 'completed'
          created_at?: string
          updated_at?: string
          primary_keyword?: string | null
          target_language?: string | null
          search_engine?: string | null
        }
      }
      search_intent_analyses: {
        Row: {
          id: string
          project_id: string
          content: string | null
          serpamics_id: string | null
          status: 'pending' | 'completed' | 'error'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          project_id: string
          content?: string | null
          serpamics_id?: string | null
          status?: 'pending' | 'completed' | 'error'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          content?: string | null
          serpamics_id?: string | null
          status?: 'pending' | 'completed' | 'error'
          created_at?: string
          updated_at?: string
        }
      }
      writing_briefs: {
        Row: {
          id: string
          project_id: string
          content: string | null
          status: 'pending' | 'completed' | 'error'
          created_at: string
          updated_at: string
          outline: Json | null
          keywords: string[] | null
          tone_of_voice: string | null
        }
        Insert: {
          id?: string
          project_id: string
          content?: string | null
          status?: 'pending' | 'completed' | 'error'
          created_at?: string
          updated_at?: string
          outline?: Json | null
          keywords?: string[] | null
          tone_of_voice?: string | null
        }
        Update: {
          id?: string
          project_id?: string
          content?: string | null
          status?: 'pending' | 'completed' | 'error'
          created_at?: string
          updated_at?: string
          outline?: Json | null
          keywords?: string[] | null
          tone_of_voice?: string | null
        }
      }
    }
  }
}