import { Project } from '../types/project';

export const projects: Project[] = [
  { id: 1, name: 'Projet 1', status: 'Analyse de l\'intention' },
  { id: 2, name: 'Projet 2', status: 'Brief de rédaction' },
  { id: 3, name: 'Projet 3', status: 'Rédaction' }
];