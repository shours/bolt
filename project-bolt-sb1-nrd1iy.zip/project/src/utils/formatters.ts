import { SaveAnalysisData } from '../types/analysis';

export const formatSavePayload = (data: SaveAnalysisData) => {
  return {
    Result: data.content,
    'Mot clef': data.keyword,
    'data: guide: id': data.serpamicsId,
    langue: data.language || 'en'
  };
};