import { SaveAnalysisData } from '../types/analysis';

export const validateSaveData = (data: SaveAnalysisData): void => {
  if (!data.serpamicsId?.match(/^[a-f0-9]{24}$/)) {
    throw new Error('Invalid serpamicsId format');
  }
  if (!data.keyword?.trim()) {
    throw new Error('Missing keyword');
  }
  if (!data.content?.trim()) {
    throw new Error('Missing content');
  }
};