import { AnalysisState } from '../types/analysis';

const STORAGE_KEY = 'analysisState';

export const persistAnalysisState = (state: Partial<AnalysisState>): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.error('Failed to persist state:', error);
  }
};

export const loadPersistedState = (): Partial<AnalysisState> => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch (error) {
    console.error('Failed to load persisted state:', error);
    return {};
  }
};