import { AnalysisFormData, AnalysisResponse } from '../types/analysis';

const extractContent = (response: string): string => {
  // Find the last occurrence of the ID pattern
  const idMatch = response.match(/[a-f0-9]{24}/);
  if (!idMatch) {
    throw new Error('Invalid response format: missing serpamicsId');
  }

  // Get everything before the ID
  const contentWithId = response.split(idMatch[0])[0];
  
  // Remove any trailing keyword and clean up
  const content = contentWithId
    .replace(/\s+\w+(\s+in\s+\w+)?$/, '') // Remove trailing keyword
    .trim();

  return content;
};

const extractSerpamicsId = (response: string): string => {
  const match = response.match(/([a-f0-9]{24})/);
  if (!match) {
    throw new Error('Invalid response format: missing or invalid serpamicsId');
  }
  return match[1];
};

const validateResponse = (response: string): void => {
  if (typeof response !== 'string' || !response.trim()) {
    throw new Error('Invalid response format: empty or non-string response');
  }
};

export const parseWebhookResponse = (
  responseData: unknown, 
  originalData: AnalysisFormData
): AnalysisResponse => {
  try {
    if (typeof responseData !== 'string') {
      throw new Error('Invalid response type: expected string');
    }

    validateResponse(responseData);
    
    const content = extractContent(responseData);
    const serpamicsId = extractSerpamicsId(responseData);
    
    return {
      content,
      serpamicsId,
      keyword: originalData.keyword,
      language: originalData.language === 'fr' ? 'Français' : 'English'
    };
  } catch (error) {
    console.error('Response parsing error:', error);
    console.error('Raw response:', responseData);
    throw new Error('Failed to parse webhook response');
  }
};