import React, { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useProjects } from '../hooks/useProjects';
import NewProjectModal from '../components/project/NewProjectModal';
import DeleteProjectModal from '../components/project/DeleteProjectModal';

const ProjectsPage = () => {
  const navigate = useNavigate();
  const { projects, isLoading, error, createProject, deleteProject } = useProjects();
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [deleteProjectData, setDeleteProjectData] = useState<{ id: string; name: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleCreateProject = async (data: { name: string }) => {
    try {
      const project = await createProject(data);
      setIsNewProjectModalOpen(false);
      navigate(`/analysis/${project.id}`);
    } catch (error) {
      console.error('Failed to create project:', error);
    }
  };

  const handleDeleteProject = async () => {
    if (!deleteProjectData) return;
    
    try {
      setIsDeleting(true);
      await deleteProject(deleteProjectData.id);
      setDeleteProjectData(null);
    } catch (error) {
      console.error('Failed to delete project:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'analysis':
        return 'Analyse de l\'intention';
      case 'brief':
        return 'Brief de rédaction';
      case 'writing':
        return 'Rédaction';
      default:
        return status;
    }
  };

  const handleEditProject = (projectId: string, status: string) => {
    switch (status) {
      case 'analysis':
        navigate(`/analysis/${projectId}`);
        break;
      case 'brief':
        navigate(`/brief/${projectId}`);
        break;
      case 'writing':
        navigate(`/writing/${projectId}`);
        break;
      default:
        navigate(`/analysis/${projectId}`);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-red-600 p-4">
        Une erreur est survenue lors du chargement des projets
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Vos projets</h1>
        <button
          onClick={() => setIsNewProjectModalOpen(true)}
          className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Plus className="w-5 h-5 mr-2" />
          Nouveau projet
        </button>
      </div>

      <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr className="bg-gray-50">
              <th scope="col" className="px-6 py-3 text-left text-sm font-medium text-gray-500">
                Projet
              </th>
              <th scope="col" className="px-6 py-3 text-left text-sm font-medium text-gray-500">
                Statut
              </th>
              <th scope="col" className="px-6 py-3 text-left text-sm font-medium text-gray-500">
                Action
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {projects.map((project) => (
              <tr key={project.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {project.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {getStatusDisplay(project.status)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex space-x-3">
                    <button
                      onClick={() => handleEditProject(project.id, project.status)}
                      className="text-gray-400 hover:text-indigo-600 transition-colors"
                    >
                      <Pencil className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => setDeleteProjectData({ id: project.id, name: project.name })}
                      className="text-gray-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {projects.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">Aucun projet pour le moment</p>
        </div>
      )}

      <NewProjectModal
        isOpen={isNewProjectModalOpen}
        onClose={() => setIsNewProjectModalOpen(false)}
        onSubmit={handleCreateProject}
        isLoading={isLoading}
      />

      <DeleteProjectModal
        isOpen={!!deleteProjectData}
        projectName={deleteProjectData?.name ?? ''}
        onClose={() => setDeleteProjectData(null)}
        onConfirm={handleDeleteProject}
        isLoading={isDeleting}
      />
    </div>
  );
};

export default ProjectsPage;