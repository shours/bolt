import React from 'react';
import { FileText } from 'lucide-react';
import AnalysisForm from '../components/analysis/AnalysisForm';
import AnalysisResult from '../components/analysis/AnalysisResult';
import LoadingModal from '../components/common/LoadingModal';
import { useAnalysis } from '../hooks/useAnalysis';

const AnalysisPage = () => {
  const { state, handleSubmit, handleEdit, handleSave } = useAnalysis();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <LoadingModal isOpen={state.isLoading} />
      
      <div className="flex items-center space-x-3 mb-8">
        <div className="bg-pink-100 p-2 rounded">
          <FileText className="w-5 h-5 text-pink-500" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900">Analyse de l'intention</h1>
      </div>
      
      <AnalysisForm 
        onSubmit={handleSubmit}
        isLoading={state.isLoading}
      />

      {state.error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600">{state.error}</p>
        </div>
      )}

      {state.result && !state.isLoading && (
        <AnalysisResult
          content={state.result}
          isEditing={state.isEditing}
          keyword={state.keyword}
          language={state.language}
          serpamicsId={state.serpamicsId}
          onEdit={handleEdit}
          onSave={handleSave}
        />
      )}
    </div>
  );
};

export default AnalysisPage;