import React from 'react';
import { Pencil, Save } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AnalysisResultProps {
  content: string;
  isEditing: boolean;
  keyword?: string | null;
  language?: string | null;
  serpamicsId?: string | null;
  onEdit: () => void;
  onSave: (content: string) => void;
}

const AnalysisResult = ({ 
  content, 
  isEditing, 
  keyword,
  language,
  serpamicsId,
  onEdit, 
  onSave 
}: AnalysisResultProps) => {
  const [editedContent, setEditedContent] = React.useState(content);

  React.useEffect(() => {
    setEditedContent(content);
  }, [content]);

  const handleSave = () => {
    onSave(editedContent);
  };

  return (
    <div className="mt-8 bg-white p-6 rounded-lg shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Analyse de l'intention des résultats de la SERP</h3>
          {keyword && (
            <p className="text-sm text-gray-500 mt-1">
              Mot clef: {keyword} | Langue: {language} {serpamicsId && `| ID: ${serpamicsId}`}
            </p>
          )}
        </div>
        <div className="flex space-x-2">
          {!isEditing ? (
            <button
              onClick={onEdit}
              className="inline-flex items-center px-3 py-1.5 border border-indigo-600 text-indigo-600 rounded-md hover:bg-indigo-50"
            >
              <Pencil className="w-4 h-4 mr-1" />
              Éditer
            </button>
          ) : (
            <button
              onClick={handleSave}
              className="inline-flex items-center px-3 py-1.5 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            >
              <Save className="w-4 h-4 mr-1" />
              Enregistrer
            </button>
          )}
        </div>
      </div>

      {isEditing ? (
        <textarea
          value={editedContent}
          onChange={(e) => setEditedContent(e.target.value)}
          className="w-full h-[600px] p-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
        />
      ) : (
        <div className="prose prose-sm max-w-none">
          <ReactMarkdown>{content}</ReactMarkdown>
        </div>
      )}
    </div>
  );
};

export default AnalysisResult;