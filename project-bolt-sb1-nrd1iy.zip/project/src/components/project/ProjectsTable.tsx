import React from 'react';
import { Pencil, Trash2 } from 'lucide-react';
import { projects } from '../../data/projects';
import { TableHeader } from './TableHeader';
import { TableRow } from './TableRow';

const ProjectsTable = () => {
  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <table className="w-full">
        <TableHeader />
        <tbody className="divide-y divide-gray-200">
          {projects.map((project) => (
            <TableRow key={project.id} project={project} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProjectsTable;