import React from 'react';
import { Pencil, Trash2 } from 'lucide-react';
import { Project } from '../../types/project';

interface TableRowProps {
  project: Project;
}

export const TableRow = ({ project }: TableRowProps) => {
  return (
    <tr>
      <td className="px-6 py-4 text-sm text-gray-700">{project.name}</td>
      <td className="px-6 py-4 text-sm text-gray-700">{project.status}</td>
      <td className="px-6 py-4 text-sm text-gray-700">
        <div className="flex space-x-3">
          <button className="text-gray-600 hover:text-indigo-600">
            <Pencil className="w-5 h-5" />
          </button>
          <button className="text-gray-600 hover:text-red-600">
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </td>
    </tr>
  );
};