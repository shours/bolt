import React from 'react';
import { Home } from 'lucide-react';

const ProjectCard = () => {
  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200 hover:border-indigo-500 transition-colors cursor-pointer">
      <div className="flex items-center space-x-3 text-gray-700">
        <Home className="w-5 h-5 text-pink-500" />
        <span>Projet 1</span>
      </div>
    </div>
  );
};

export default ProjectCard;