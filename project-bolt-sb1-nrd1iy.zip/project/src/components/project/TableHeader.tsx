import React from 'react';

export const TableHeader = () => {
  return (
    <thead>
      <tr className="bg-gray-50">
        <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Projet</th>
        <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Statut</th>
        <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Action</th>
      </tr>
    </thead>
  );
};