import React from 'react';

const ProjectContent = () => {
  return (
    <div className="p-6 space-y-6">
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <button className="w-full bg-indigo-500 text-white py-2 rounded-lg hover:bg-indigo-600">
          bouton
        </button>
        
        <div className="mt-6">
          <h3 className="text-sm text-gray-600 mb-2">titre</h3>
          <div className="flex space-x-2 mb-4">
            <button className="px-4 py-1 rounded-full border border-indigo-500 text-indigo-500 hover:bg-indigo-50">
              Editer
            </button>
            <button className="px-4 py-1 rounded-full border border-indigo-500 text-indigo-500 hover:bg-indigo-50">
              Lire
            </button>
          </div>
          
          <div className="space-y-4">
            <div>
              <h4 className="text-sm text-gray-600 mb-2">Analyse du mot clef :</h4>
              <p className="text-gray-500">texte de l'analyse</p>
            </div>
          </div>
        </div>
      </div>
      
      <button className="bg-indigo-500 text-white px-6 py-2 rounded-lg hover:bg-indigo-600 float-right">
        Enregistrer
      </button>
    </div>
  );
};

export default ProjectContent;