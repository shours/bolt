import React from 'react';
import { LayoutGrid, FileText, ImageIcon, Clock } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useProjectState } from '../../hooks/useProjectState';

const Sidebar = () => {
  const { hasAnalysis, hasBrief } = useProjectState();
  const location = useLocation();

  const isActive = (path: string) => location.pathname.startsWith(path);

  return (
    <div className="w-64 h-screen bg-white border-r border-gray-200 flex flex-col">
      <div className="p-4">
        <div className="bg-gray-100 w-24 h-8 rounded flex items-center justify-center">
          <span className="text-gray-600 font-semibold">LOGO</span>
        </div>
      </div>
      
      <div className="flex-1 px-4">
        <div className={`rounded-lg p-2 mb-4 ${isActive('/projects') ? 'bg-indigo-50' : ''}`}>
          <Link 
            to="/projects" 
            className={`flex items-center px-3 py-2 rounded-lg ${
              isActive('/projects') ? 'text-indigo-600' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <LayoutGrid className="w-5 h-5 mr-3" />
            <span>Projets</span>
          </Link>
        </div>
        
        <nav className="space-y-1">
          <Link
            to="/analysis"
            className={`flex items-center px-3 py-2 rounded-lg ${
              isActive('/analysis') 
                ? 'bg-indigo-50 text-indigo-600'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <FileText className="w-5 h-5 mr-3" />
            <span>Analyse intention</span>
          </Link>
          
          <Link
            to={hasAnalysis ? '/brief' : '#'}
            className={`flex items-center px-3 py-2 rounded-lg ${
              !hasAnalysis 
                ? 'text-gray-400 cursor-not-allowed'
                : isActive('/brief')
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'text-gray-600 hover:bg-gray-50'
            }`}
            onClick={(e) => !hasAnalysis && e.preventDefault()}
          >
            <ImageIcon className="w-5 h-5 mr-3" />
            <span>Brief de rédaction</span>
          </Link>
          
          <Link
            to={hasBrief ? '/writing' : '#'}
            className={`flex items-center px-3 py-2 rounded-lg ${
              !hasBrief 
                ? 'text-gray-400 cursor-not-allowed'
                : isActive('/writing')
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'text-gray-600 hover:bg-gray-50'
            }`}
            onClick={(e) => !hasBrief && e.preventDefault()}
          >
            <Clock className="w-5 h-5 mr-3" />
            <span>Rédaction</span>
          </Link>
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;