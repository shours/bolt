import React from 'react';
import { LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface HeaderProps {
  onSignOut: () => void;
}

const Header = ({ onSignOut }: HeaderProps) => {
  const { user } = useAuth();
  
  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-end px-6">
      <div className="flex items-center space-x-4">
        <button 
          onClick={onSignOut}
          className="text-gray-600 hover:text-gray-900 flex items-center"
        >
          <LogOut className="w-5 h-5 mr-2" />
          Déconnexion
        </button>
        <div className="w-8 h-8 bg-gray-200 rounded-full overflow-hidden">
          <img
            src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.email}`}
            alt="Avatar"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </header>
  );
};

export default Header;