import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Database } from '../types/database';
import { supabase } from '../lib/supabase';
import { AnalysisResponse } from '../types/analysis';

type Analysis = Database['public']['Tables']['search_intent_analyses']['Row'];
type AnalysisInsert = Database['public']['Tables']['search_intent_analyses']['Insert'];

export const useAnalysisStorage = (projectId: string) => {
  const queryClient = useQueryClient();

  const analysisQuery = useQuery({
    queryKey: ['analysis', projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('search_intent_analyses')
        .select('*')
        .eq('project_id', projectId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!projectId,
  });

  const saveAnalysis = useMutation({
    mutationFn: async (analysis: AnalysisResponse) => {
      const analysisData: AnalysisInsert = {
        project_id: projectId,
        content: analysis.content,
        serpamics_id: analysis.serpamicsId,
        status: 'completed'
      };

      const { data, error } = await supabase
        .from('search_intent_analyses')
        .upsert({
          ...analysisData,
          project_id: projectId,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['analysis', projectId] });
      queryClient.invalidateQueries({ queryKey: ['projects'] });
    },
  });

  return {
    analysis: analysisQuery.data,
    isLoading: analysisQuery.isLoading,
    error: analysisQuery.error,
    saveAnalysis: saveAnalysis.mutate,
  };
};