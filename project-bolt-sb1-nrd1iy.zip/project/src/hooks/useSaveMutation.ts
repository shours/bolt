import { useMutation } from '@tanstack/react-query';
import { SaveAnalysisData } from '../types/analysis';
import { saveAnalysis } from '../services/saveService';

export const useSaveMutation = () => {
  return useMutation<void, Error, SaveAnalysisData>({
    mutationFn: saveAnalysis,
    onError: (error) => {
      console.error('Save mutation error:', error);
    }
  });
};