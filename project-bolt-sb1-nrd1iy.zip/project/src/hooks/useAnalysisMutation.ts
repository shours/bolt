import { useMutation } from '@tanstack/react-query';
import { AnalysisFormData, AnalysisResponse } from '../types/analysis';
import { analyzeKeyword } from '../services/analysisService';

export const useAnalysisMutation = () => {
  return useMutation<AnalysisResponse, Error, AnalysisFormData>({
    mutationFn: analyzeKeyword,
    onError: (error) => {
      console.error('Analysis mutation error:', {
        message: error.message,
        stack: error.stack
      });
    },
    retry: 1
  });
};