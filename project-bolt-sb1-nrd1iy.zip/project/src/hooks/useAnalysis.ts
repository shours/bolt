import { useState, useCallback, useEffect } from 'react';
import { AnalysisFormData, AnalysisState } from '../types/analysis';
import { useAnalysisMutation } from './useAnalysisMutation';
import { useSaveMutation } from './useSaveMutation';
import { useProjectState } from './useProjectState';
import { persistAnalysisState, loadPersistedState } from '../utils/storage';

const initialState: AnalysisState = {
  isLoading: false,
  error: null,
  result: null,
  isEditing: false,
  serpamicsId: null,
  keyword: null,
  language: null
};

export const useAnalysis = () => {
  const [state, setState] = useState<AnalysisState>(() => ({
    ...initialState,
    ...loadPersistedState()
  }));
  
  const { setHasAnalysis } = useProjectState();
  const analysisMutation = useAnalysisMutation();
  const saveMutation = useSaveMutation();

  useEffect(() => {
    if (state.result) {
      persistAnalysisState({
        result: state.result,
        serpamicsId: state.serpamicsId,
        keyword: state.keyword,
        language: state.language
      });
      setHasAnalysis(true);
    }
  }, [state.result, state.serpamicsId, state.keyword, state.language, setHasAnalysis]);

  const handleSubmit = useCallback(async (data: AnalysisFormData) => {
    try {
      setState(prev => ({ 
        ...prev, 
        isLoading: true, 
        error: null,
        result: null 
      }));
      
      const result = await analysisMutation.mutateAsync(data);
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        result: result.content,
        serpamicsId: result.serpamicsId,
        keyword: result.keyword,
        language: result.language,
        error: null
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: error instanceof Error ? error.message : 'An error occurred during analysis',
        result: null
      }));
    }
  }, [analysisMutation]);

  const handleEdit = useCallback(() => {
    setState(prev => ({ ...prev, isEditing: true }));
  }, []);

  const handleSave = useCallback(async (content: string) => {
    if (!state.serpamicsId || !state.keyword) {
      setState(prev => ({
        ...prev,
        error: 'Missing required data for save'
      }));
      return;
    }

    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      await saveMutation.mutateAsync({
        serpamicsId: state.serpamicsId,
        keyword: state.keyword,
        content: content,
        language: state.language
      });

      setState(prev => ({
        ...prev,
        isLoading: false,
        isEditing: false,
        result: content,
        error: null
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Failed to save changes'
      }));
    }
  }, [state.serpamicsId, state.keyword, state.language, saveMutation]);

  return {
    state,
    handleSubmit,
    handleEdit,
    handleSave,
  };
};