import { create } from 'zustand';

interface ProjectState {
  hasAnalysis: boolean;
  hasBrief: boolean;
  setHasAnalysis: (value: boolean) => void;
  setHasBrief: (value: boolean) => void;
}

export const useProjectState = create<ProjectState>((set) => ({
  hasAnalysis: false,
  hasBrief: false,
  setHasAnalysis: (value) => set({ hasAnalysis: value }),
  setHasBrief: (value) => set({ hasBrief: value }),
}));